# Python Programming - CO5 Assignment

Extracted and reconstructed Python programs from the uploaded 23-page assignment PDF.

## Tasks
1. Data Acquisition
2. Cleaning and Normalisation
3. Analysis and Visualisation
4. Debugging and Profiling
5. AI Application for Citizen Complaints
6. Cleaning Pipeline
7. Adversarial Data and SQL Injection Testing
8. Loops vs Libraries vs SQL
9. Final Engineering Decision

## Install required libraries
```bash
pip install pandas matplotlib
```

## Run
Run each Python file separately:
```bash
python task1_data_acquisition.py
```

The programs create CSV, SQLite database, and chart files in the current folder as applicable.

**Note:** The original PDF displays code as screenshots. These files are readable, runnable transcriptions/reconstructions of the visible code; verify against the PDF before final submission.
