import sqlite3
import time

POSITIVE = {
    "good", "clean", "safe", "helpful", "improved",
    "excellent", "better", "healthy"
}
NEGATIVE = {
    "bad", "dirty", "slow", "rude", "smoke",
    "broken", "poor", "unsafe"
}
NEGATORS = {"not", "never", "no"}

def score(text):
    words = text.lower().replace(".", " ").replace(",", " ").split()
    total = 0
    for index, word in enumerate(words):
        value = 1 if word in POSITIVE else -1 if word in NEGATIVE else 0
        if index > 0 and words[index - 1] in NEGATORS:
            value = -value
        total += value
    return total

def label(text):
    result = score(text)
    if result > 0:
        return "Positive"
    if result < 0:
        return "Negative"
    return "Neutral"

def summarise(text):
    sentences = text.split(".")
    return ". ".join(
        sentence.strip() for sentence in sentences[:2] if sentence.strip()
    )

complaints = [
    "Roads are clean and the bus was fast.",
    "Smoke from the factory air is bad.",
    "The staff were not helpful.",
    "Not bad, service improved.",
    "The environment is excellent.",
    "The road is dirty and unsafe.",
    "Transport service is slow.",
    "The area is clean and safe.",
    "The machine is broken.",
    "The service is good."
]

print("AI COMPLAINT ANALYSIS")
print("--------------------")
for complaint in complaints:
    print(label(complaint), "|", complaint, "| Score:", score(complaint))

print("\\nMISCLASSIFICATION TEST")
test = "The service is not good."
print("Complaint:", test)
print("Predicted sentiment:", label(test))
print("Expected sentiment: Negative")
print("Note: Simple word-based models may misclassify sentences.")

print("\\nTEXT SUMMARISATION")
report = (
    "Air pollution affects public health. "
    "People reported smoke and dirty roads. "
    "Clean transport can improve the environment."
)
print("Original Report:", report)
print("Summary:", summarise(report))

# Store complaints and measure query time before and after indexing.
con = sqlite3.connect("task9.db")
cur = con.cursor()
cur.execute("DROP TABLE IF EXISTS complaints")
cur.execute("""
CREATE TABLE complaints (
    id INTEGER PRIMARY KEY,
    complaint TEXT,
    sentiment TEXT
)
""")
records = [
    (i, complaint, label(complaint))
    for i, complaint in enumerate(complaints, start=1)
]
cur.executemany("INSERT INTO complaints VALUES (?, ?, ?)", records)
con.commit()

query = """
SELECT * FROM complaints
WHERE sentiment = 'Negative'
"""

start = time.perf_counter()
for _ in range(1000):
    cur.execute(query)
    cur.fetchall()
before_index = time.perf_counter() - start

cur.execute("""
CREATE INDEX IF NOT EXISTS sentiment_index
ON complaints(sentiment)
""")
con.commit()

start = time.perf_counter()
for _ in range(1000):
    cur.execute(query)
    cur.fetchall()
after_index = time.perf_counter() - start

print("\\nDATABASE INDEXING")
print("Time before index:", round(before_index, 6), "seconds")
print("Time after index:", round(after_index, 6), "seconds")

print("\\nCOMPLAINT SUMMARY")
cur.execute("""
SELECT sentiment, COUNT(*)
FROM complaints
GROUP BY sentiment
""")
for row in cur.fetchall():
    print(row)

con.close()
print("\\nTASK 9 COMPLETED")
