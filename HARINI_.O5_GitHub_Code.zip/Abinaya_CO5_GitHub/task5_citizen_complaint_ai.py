import re

def summarise(text):
    sentences = re.split(r"(?<=[.!?])\\s+", text.strip())
    return " ".join(sentence for sentence in sentences[:2] if sentence)

positive_words = ["good", "happy", "excellent", "clean", "helpful"]
negative_words = ["bad", "dirty", "poor", "slow", "rude"]
negations = {"not", "never", "no"}

def sentiment_analysis(text):
    words = re.findall(r"\\b[\\w']+\\b", text.lower())
    score = 0
    for index, word in enumerate(words):
        value = 1 if word in positive_words else -1 if word in negative_words else 0
        if index > 0 and words[index - 1] in negations:
            value *= -1
        score += value

    if score > 0:
        return "Positive"
    if score < 0:
        return "Negative"
    return "Neutral"

def chatbot(message):
    message = message.lower()
    if "hello" in message or "hi" in message:
        return "Hello! Welcome to AI Assistant."
    if "air quality" in message or "pm2.5" in message:
        return "Air quality monitoring helps us understand pollution."
    if "thank" in message:
        return "You are welcome!"
    if "bye" in message:
        return "Goodbye! Have a nice day."
    return "Sorry, I do not understand your message."

text = (
    "Air pollution affects human health. "
    "Clean air is important for everyone. "
    "Trees help improve the environment."
)

print("TEXT SUMMARISATION")
print("Original Text:", text)
print("Summary:", summarise(text))

print("\\nSENTIMENT ANALYSIS")
reviews = [
    "The environment is clean and good",
    "The area is dirty and bad",
    "The weather is normal"
]
for review in reviews:
    print(review, ":", sentiment_analysis(review))

print("\\nAI CHATBOT")
for message in ["Hello", "Tell me about air quality", "Thank you"]:
    print("User:", message)
    print("Bot:", chatbot(message))

print("\\nTASK 5 COMPLETED")
