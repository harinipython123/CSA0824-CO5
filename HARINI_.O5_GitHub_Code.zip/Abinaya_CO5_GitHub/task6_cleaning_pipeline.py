import csv
import sqlite3
import os

# Create a sample CSV dataset.
raw_data = [
    ["station", "date", "pm25"],
    ["Adyar", "2026-10-01", "48"],
    ["Adyar", "2026-10-02", "NA"],
    ["Adyar", "2026-10-03", "121"],
    ["Guindy", "2026-10-01", "95"],
    ["Guindy", "2026-10-02", "-5"],
    ["Guindy", "2026-10-03", "121"],
]

with open("raw_air_quality.csv", "w", newline="") as file:
    csv.writer(file).writerows(raw_data)
print("RAW CSV FILE CREATED")

# Read CSV and clean data.
cleaned_rows = []
with open("raw_air_quality.csv", newline="") as file:
    reader = csv.DictReader(file)
    for row in reader:
        value = row["pm25"].strip()
        if value == "" or value.upper() == "NA":
            continue
        try:
            pm25 = float(value)
        except ValueError:
            continue
        if pm25 < 0 or pm25 > 999:
            continue
        cleaned_rows.append((row["station"], row["date"], pm25))

print("\\nCLEANED DATA")
for row in cleaned_rows:
    print(row)

# Min-max normalisation.
values = [row[2] for row in cleaned_rows]
minimum, maximum = min(values), max(values)
if maximum != minimum:
    normalised = [round((value - minimum) / (maximum - minimum), 3)
                  for value in values]
else:
    normalised = [0.0 for _ in values]

print("\\nNORMALISED VALUES")
print(normalised)

# Save cleaned CSV.
with open("cleaned_task6.csv", "w", newline="") as file:
    writer = csv.writer(file)
    writer.writerow(["station", "date", "pm25", "normalised_pm25"])
    for row, norm in zip(cleaned_rows, normalised):
        writer.writerow([*row, norm])

# Store records in SQLite.
con = sqlite3.connect("air_quality_task6.db")
cur = con.cursor()
cur.execute("DROP TABLE IF EXISTS readings")
cur.execute("""
CREATE TABLE readings (
    station TEXT,
    date TEXT,
    pm25 REAL,
    normalised_pm25 REAL
)
""")
records = [(*row, norm) for row, norm in zip(cleaned_rows, normalised)]
cur.executemany("INSERT INTO readings VALUES (?, ?, ?, ?)", records)
con.commit()

print("\\nSTATION-WISE AVERAGE PM2.5")
cur.execute("SELECT station, AVG(pm25) FROM readings GROUP BY station")
for row in cur.fetchall():
    print(row)
con.close()

# Create chart if matplotlib is installed.
try:
    import matplotlib.pyplot as plt
    stations = [row[0] for row in cleaned_rows]
    pm_values = [row[2] for row in cleaned_rows]
    plt.bar(stations, pm_values)
    plt.title("Air Quality PM2.5 Readings")
    plt.xlabel("Station")
    plt.ylabel("PM2.5")
    plt.savefig("task6_chart.png")
    plt.show()
    print("\\nCHART SAVED SUCCESSFULLY")
except ImportError:
    print("\\nMatplotlib is not installed. Chart skipped.")

print("\\nCLEANED CSV AND DATABASE SAVED")
print("TASK 6 COMPLETED")
